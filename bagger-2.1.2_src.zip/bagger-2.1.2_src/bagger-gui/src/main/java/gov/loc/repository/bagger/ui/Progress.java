package gov.loc.repository.bagger.ui;

public interface Progress {

	void execute();

}
