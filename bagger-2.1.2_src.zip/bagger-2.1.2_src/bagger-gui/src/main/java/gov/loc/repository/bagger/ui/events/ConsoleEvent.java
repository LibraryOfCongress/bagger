package gov.loc.repository.bagger.ui.events;

public class ConsoleEvent {

}
