                              README

                    Bagger, Stand-Alone Edition
                             Version 1.7


The Bagger Stand-Alone Edition is intended for users with no or 
limited Internet web access.

It contains the Bagger signed executable jar file as well as an
embedded Java 1.6 JRE runtime library.  This edition contains
executable versions of Bagger as well as the Java JRE so that
users within administrative privileges to install programs can
run Bagger.


======================================================================
   Executing Bagger with access to the Library of Congress Web site
======================================================================

In order to access the Bagger application via the web, access the
Library of Congress Repository Development Center website:

    http://baggertest.rdc.lctl.gov/bagger/

-----------------------------------------------------------------------
   Running the stand-alone version of Bagger on Windows
-----------------------------------------------------------------------

To run the Bagger application, go to the folder bagger_stndalone_win. 
Double click on the file bagger_stndalone.bat, or select 
Start->Run->Browse... then navigate to the bagger_stndalone.bat file
and select Open and then Ok in the Run dialog window.

To create a shortcut on your desktop, select the bagger_stndalone.bat
file and select the right mouse button.  Select Send to->Desktop (create shortcut)

-----------------------------------------------------------------------

Bagger is a product of The United States Library of Congress

101 Independence Ave SE, Washington, DC 20540, U.S.A.

