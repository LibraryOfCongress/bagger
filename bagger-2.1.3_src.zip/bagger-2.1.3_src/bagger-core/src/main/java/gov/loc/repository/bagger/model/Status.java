package gov.loc.repository.bagger.model;

public enum Status {
	PASS, FAILURE, UNKNOWN
}
